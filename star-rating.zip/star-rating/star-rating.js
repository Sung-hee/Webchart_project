var getParam = function(key){
    var _parammap = {};
    document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
        function decode(s) {
            return decodeURIComponent(s.split("+").join(" "));
        }

        _parammap[decode(arguments[1])] = decode(arguments[2]);
    });

    return _parammap[key];
};

var companycode = getParam("name");


$(document).ready(function(){
  $.getJSON('http://61.72.187.6/phps/now?name=' + companycode, function(data){
    var json_data = '';

    $.each(data, function(key, value){
        const ratings = {
          hotel_a : value.gold,
        };
        const starTotal = 100;

        for(const rating in ratings) {
        // 2
        const starPercentage = (ratings[rating] / starTotal) * 100;
        // 3
        const starPercentageRounded = `${(Math.round(starPercentage / 10) * 10)}%`;
        // 4
        document.querySelector(`.${rating} .stars-inner`).style.width = starPercentageRounded;
        }
        // 파워등급
        if(value.power == "1 등급" || value.power == "1.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 100%;">';
          if(value.power =="1 등급"){
            json_data += '<span class="asd" style="color:black">1등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">1.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp파워등급</span>';
          json_data += '</div>'
        }
        else if(value.power == "2 등급" || value.power == "2.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 80%;">';
          if(value.power =="2 등급"){
            json_data += '<span class="asd" style="color:black">2등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">2.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp파워등급</span>';
          json_data += '</div>'
        }
        else if(value.power == "3 등급" || value.power == "3.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 60%;">';
          if(value.power =="3 등급"){
            json_data += '<span class="asd" style="color:black">3등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">3.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp파워등급</span>';
          json_data += '</div>'
        }
        else if(value.power == "4 등급" || value.power == "4.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="height: 40%;">';
          if(value.power =="4 등급"){
            json_data += '<span class="asd" style="color:black">4등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">4.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp파워등급</span>';
          json_data += '</div>'
        }
        else if(value.power == "5 등급" || value.power == "5.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="height: 20%; background-color:#767676">';
          if(value.power =="5 등급"){
            json_data += '<span class="asd" style="color:black">5등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">5.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp파워등급</span>';
          json_data += '</div>'
        }
        else {
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="height: 20%; background-color:#F5F5F5;">';
          json_data += '<span class="asd" style="color:black"> 낙 제</span>';
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp파워등급</span>';
          json_data += '</div>'
        }

        //수급
        if(value.supl == "1 등급" || value.supl == "1.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 100%;">';
          if(value.supl =="1 등급"){
            json_data += '<span class="asd" style="color:black">1등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">1.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp수급등급</span>';
          json_data += '</div>'
        }
        else if(value.supl == "2 등급" || value.supl == "2.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 80%;">';
          if(value.supl =="2 등급"){
            json_data += '<span class="asd" style="color:black">2등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">2.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp수급등급</span>';
          json_data += '</div>'
        }
        else if(value.supl == "3 등급" || value.supl == "3.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 60%;">';
          if(value.supl =="3 등급"){
            json_data += '<span class="asd" style="color:black">3등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">3.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp수급등급</span>';
          json_data += '</div>'
        }
        else if(value.supl == "4 등급" || value.supl == "4.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="height: 40%;">';
          if(value.supl =="4 등급"){
            json_data += '<span class="asd" style="color:black">4등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">4.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp수급등급</span>';
          json_data += '</div>'
        }
        else if(value.supl == "5 등급" || value.supl == "5.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="height: 20%; background-color:#767676">';
          if(value.supl =="5 등급"){
            json_data += '<span class="asd" style="color:black">5등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">5.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp수급등급</span>';
          json_data += '</div>'
        }
        else {
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="height: 20%; background-color:#F5F5F5;">';
          json_data += '<span class="asd" style="color:black"> 낙 제</span>';
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp수급등급</span>';
          json_data += '</div>'
        }

        //실적
        if(value.perform == "1 등급" || value.perform == "1.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 100%;">';
          if(value.perform =="1 등급"){
            json_data += '<span class="asd" style="color:black">1등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">1.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp실적등급</span>';
          json_data += '</div>'
        }
        else if(value.perform == "2 등급" || value.perform == "2.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 80%;">';
          if(value.perform =="2 등급"){
            json_data += '<span class="asd" style="color:black">2등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">2.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp실적등급</span>';
          json_data += '</div>'
        }
        else if(value.perform == "3 등급" || value.perform == "3.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="height: 60%;">';
          if(value.perform =="3 등급"){
            json_data += '<span class="asd" style="color:black">3등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">3.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp실적등급</span>';
          json_data += '</div>'
        }
        else if(value.perform == "4 등급" || value.perform == "4.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="height: 40%;">';
          if(value.perform =="4 등급"){
            json_data += '<span class="asd" style="color:black">4등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">4.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp실적등급</span>';
          json_data += '</div>'
        }
        else if(value.perform == "5 등급" || value.perform == "5.5 등급"){
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="height: 20%; background-color:#767676">';
          if(value.perform =="5 등급"){
            json_data += '<span class="asd" style="color:black">5등급</span>';
          }
          else {
            json_data += '<span class="qwe" style="color:black">5.5등급</span>';
          }
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp실적등급</span>';
          json_data += '</div>'
        }
        else {
          json_data += '<div class="progress progress-bar-vertical">';
          json_data += '<div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="height: 20%; background-color:#F5F5F5;">';
          json_data += '<span class="asd" style="color:black"> 낙 제</span>';
          json_data += '</div>';
          json_data += '<span class="zxc">&nbsp실적등급</span>';
          json_data += '</div>'
        }
    });
    $('#company_score').append(json_data);
  });
});
